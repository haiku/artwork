Haikus are defined by their short length and their references to nature.  These are the aspects I wanted to capture in my submission for Haiku's soundscape, "Nature."  To achieve this, I went outside and recorded natural sounds as a basis on which to work: the sound of a pond, of wind blowing*, of branches shaking (more precisely, being shaken), and of rocks falling.  Each sound in this set, aside from the beep, startup, and shutdown chimes, originates from these recordings.  I am unaware of any major operating system having used natural sounds as the main basis of their system sounds; this reflects Haiku's uniqueness.

The resulting system sounds included here evoke nature, are short, and are generally non-intrusive.  Here is a brief explanation of the source and style of each sound:


----------------------
Notifications
----------------------
- Information notification
Brief, indistinct musical "howl".  It's the edited sound of wind.
- Important notification:
The plop of something falling into water.  Edited excerpt of a pond fountain.
- Error notification
A kind of angry groaning.  Originates from the sound of wind, but heavily edited by normalizing this sound and adding pitch-shifting.  Unlike the other sounds, this one is meant to be a bit unnatural and intrusive - if an error occurs, it should get the user's attention, though not in an annoying way.
- Progress notification
A quiet breeze.  Intended to be soothing and soft, since it will presumably play multiple times in a row.  Gives the impression of progress gently being made.

----------------------
Key/mouse sounds
----------------------
- Key down
The sound of a rock being dropped on other rocks.  A natural counterpart to the clack of a typewriter.
- Key repeat
From the same sound source as key down, slightly shorter and pitched lower since it may be heard repeatedly.
- Key up
A higher-pitched version of the key down sound.
- Keymap switch
The sound of multiple rocks falling, to mimick the sound of a typewriter carriage return, or maybe all the keys being removed and shifted around.
- Mouse down
A very brief clip of the moment a rock hits the ground, as though the mouse button has been clicked in with force.
- Mouse up
A higher, shorter version of the mouse down sound.

----------------------
Window sounds
----------------------
All of the window sounds are based on the same wind sound (get it?  WINDow?), pitched differently and with different intensities and lengths depending on the window action.  However, they are all fairly similar, as they are meant to accentuate user actions and not to stand out on their own.

- Window activated
A very brief and quiet swoosh, like a ninja dashing by, to indicate a shift in focus.
- Window close
A falling downwards sound.  What it would sound like if wind could be dejected, as though a program is being shown the door.
- Window minimised
A slightly downward blow - like the window close sound, but not as dramatic.
- Window open
The longest window action sound, a sort of swooping upwards, to echo a program being started.
- Window restored (= gets ‘unminimised’)
Very similar to the window open sound, but slightly shorter.
- Window zoomed
A much more subdued, lower swoosh sound, to reflect that the window zooming is not as momentous as being opened, minimised, or restored.

----------------------
Chimes
----------------------
These sounds are unique in the set: unlike every other sound, the startup chime and the system beep (as well as the shutdown chime included under "Extra Sounds") are made from generated, pure tones.  This reflects their purpose as indicating 'artificial' operating system events that in turn enable the naturalistic sounds used elsewhere.  It's like being in a Star Trek holodeck, enjoying a holographic nature scene -- these sounds are the computer chirps made when the holodeck itself is being controlled or interacted with.

- Beep
A simple two-note chime that fades in and out.  Sounds akin to a doorbell - like a doorbell, this is an event that should get the user's attention.
- Startup chime
A quick, high-pitched four-note ringing, rather like wind chimes.  It lets the user know the computer is ready to use, and maintains a simple, cheerful spirit.

----------------------
Extra Sounds
----------------------
I created some sounds that may be useful in Haiku, although they were not called for in the contest instructions.

- Critical error
A loud, multi-tonal thud.  Like the error sound, it's based on a normalized wind sound, but this one has more finality to it.  I arrived at it by accident - in a sort of convergent evolution, it ended up similar to the Windows XP critical error sound, hence it being included as such.
- Move to trash
Similar to the keymap switch, but shorter and much softer.  It's the sound of falling rocks, but sounds a bit like paper being crumpled up.
- Empty trash
A loud splash, like something heavy being thrown into a river to be carried away and never seen again.
- Shutdown chime
Every OS should have a shutdown chime!  This one is quite quick and pitches downwards.  Its short length reflects both that Haiku is designed to be responsive, and that future computers will increasingly use SSDs as main storage; thus, shutdown is and will be quick, so the chime should not waste time.



*full disclosure: this ended up being the sound of me imitating wind and blowing into the microphone, as there were no interesting natural wind sounds for me to capture.  It ended up sounding far better and more realistic than that description might sound; hence I refer to it as 'wind' for brevity in the rest of the sound descriptions.